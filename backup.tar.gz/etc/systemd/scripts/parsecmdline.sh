#!/bin/bash

if test -z $1; then exit 1; fi

cmdline=$(cat /proc/cmdline)

if test -z "$cmdline"; then exit 1; fi

read -r -a params <<< $cmdline

for param in "${params[@]}"; do
    name=$(echo $param | cut -d "=" -f1)
    value=$(echo $param | cut -d "=" -f2-)

    if test "$1" == "$name"; then
        echo $value
        exit 0
    fi
done

exit 1

